import tkinter as tk
from tkinter import messagebox, simpledialog, Toplevel, Label, Entry, Button
from bank_sys_ref import BankSystem

# Initialize the bank system
bank = BankSystem()

def login():
    username = simpledialog.askstring("Login", "Enter username:")
    password = simpledialog.askstring("Login", "Enter password:", show="*")
    message, admin = bank.admin_login(username, password)
    print(message)  # Optionally print the message to the console for debugging
    if admin is not None:
        messagebox.showinfo("Login", message)
        admin_window(admin)  # Proceed to open the admin window if the admin object is returned
    else:
        messagebox.showerror("Login Failed", message)  # Show an error message if login fails

def admin_window(admin):
    window = Toplevel()
    window.title(f"Logged Admin Name - {admin.get_first_name()} {admin.get_last_name()}")
    window.geometry("800x600")
    window.configure(bg="#4CAF50")

    style = {"bg": "#2196F3", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    
    Button(window, text="Transfer Money", command=lambda: transfer_money(window), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Delete Customer", command=lambda: delete_customer(window), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Customer account operations & profile settings", command=lambda: customer_account_operations(window), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Print All Accounts", command=lambda: print_all_accounts_details(), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Save Bank Data", command=lambda: save_bank_data(), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Generate Management Report", command=lambda: generate_management_report(), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Update My Information", command=lambda: update_admin_info(window, admin), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Logout", command=lambda: logout(window), **style).pack(fill=tk.X, pady=5)

def logout(window):
    messagebox.showinfo("Logout", "Logout Successful.")
    window.destroy()

def save_bank_data():
    try:
        bank.save_bank_data()
        messagebox.showinfo("Save Successful", "Data saved successfully.")
    except Exception as e:
        messagebox.showerror("Save Failed", f"An error occurred: {str(e)}")

def print_all_accounts_details():
    details = bank.print_all_accounts_details()
    messagebox.showinfo("Details", details)

def generate_management_report():
    report = bank.generate_management_report()
    messagebox.showinfo("Management Report", report)

def customer_account_operations(parent):
    window = Toplevel(parent)
    window.title("Customer Account Operations & Profile Settings")
    window.geometry("600x600")
    window.configure(bg="#2196F3")

    Label(window, text="Enter Customer Last Name:").pack()
    customer_lname = Entry(window)
    customer_lname.pack()

    style = {"bg": "#FFC107", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(window, text="Continue", command=lambda: account_options_window(window, customer_lname.get()), **style).pack()

def account_options_window(parent, lname):
    customer = bank.search_customers_by_name(lname)
    if not customer:
        messagebox.showerror("Error", "Customer not found.")
        return

    window = Toplevel(parent)
    window.title("Account Operations for " + lname)
    window.geometry("600x600")
    window.configure(bg="#FFC107")

    style = {"bg": "#FF9800", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(window, text="Deposit Money", command=lambda: deposit_money(window, customer), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Withdraw Money", command=lambda: withdraw_money(window, customer), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Check Balance", command=lambda: check_balance(window, customer), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Update Customer Information", command=lambda: update_customer_info(window, customer), **style).pack(fill=tk.X, pady=5)

def deposit_money(window, customer):
    amount = simpledialog.askfloat("Deposit Money", "Enter amount to deposit:", minvalue=0)
    if amount is not None:
        customer.deposit(amount)
        messagebox.showinfo("Deposit Successful", f"Deposited {amount} to account {customer.get_account_no()}. New Balance: {customer.get_balance()}")

def withdraw_money(window, customer):
    amount = simpledialog.askfloat("Withdraw Money", "Enter amount to withdraw:" ,minvalue=0)
    if amount is not None and customer.withdraw(int(amount)):
        messagebox.showinfo("Withdrawal Successful", f"Withdrew {amount} from account {customer.get_account_no()}. Remaining Balance: {customer.get_balance()}")
    else:
        messagebox.showerror("Error", "Insufficient funds.")

def check_balance(window, customer):
    messagebox.showinfo("Account Balance", f"The balance for account {customer.get_account_no()} is {customer.get_balance()}.")

def update_customer_info(window, customer):
    update_window = Toplevel(window)
    update_window.title("Update Customer Information")
    update_window.geometry("600x600")
    update_window.configure(bg="#673AB7")

    Label(update_window, text="First Name:").grid(row=0, column=0)
    first_name_entry = Entry(update_window)
    first_name_entry.insert(0, customer.get_first_name())
    first_name_entry.grid(row=0, column=1)

    Label(update_window, text="Last Name:").grid(row=1, column=0)
    last_name_entry = Entry(update_window)
    last_name_entry.insert(0, customer.get_last_name())
    last_name_entry.grid(row=1, column=1)

    Label(update_window, text="Address:").grid(row=2, column=0)
    address_entry = Entry(update_window)
    address_entry.insert(0, customer.get_address())
    address_entry.grid(row=2, column=1)

    style = {"bg": "#673AB7", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(update_window, text="Save Changes", command=lambda: save_customer_changes(
        customer, first_name_entry.get(), last_name_entry.get(), address_entry.get().split(', '), update_window), **style).grid(row=3, column=0, columnspan=2)

def save_customer_changes(customer, first_name, last_name, address, window):
    if first_name and last_name and address:
        customer.update_first_name(first_name)
        customer.update_last_name(last_name)
        customer.update_address(address)
        messagebox.showinfo("Success", "Customer information updated successfully")
        window.destroy()  # Close the update window
    else:
        messagebox.showerror("Error", "All fields must be filled out")

def delete_customer(parent):
    window = Toplevel(parent)
    window.title("Delete Customer")
    window.geometry("600x200")
    window.configure(bg="#607D8B")

    Label(window, text="Enter Last Name of Customer:").grid(row=0, column=0)
    lname = Entry(window)
    lname.grid(row=0, column=1)

    style = {"bg": "#607D8B", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(window, text="Delete", command=lambda: execute_delete_customer(lname.get(), window), **style).grid(row=2, column=0, columnspan=2, sticky="ew")

def execute_delete_customer(lname, window):
    if bank.delete_customer(lname):
        messagebox.showinfo("Success", f"Customer {lname} deleted successfully")
    else:
        messagebox.showerror("Failed", f"No customer found with last name {lname}")
    window.destroy()

def add_customer(parent):
    window = Toplevel(parent)
    window.title("Add Customer")
    window.geometry("600x400")
    window.configure(bg="#009688")

    fields = ["First Name", "Last Name", "Address", "Account Number", "Balance", "Account Type", "Interest Rate", "Overdraft Limit"]
    entries = {}
    for idx, field in enumerate(fields):
        Label(window, text=field+":").grid(row=idx, column=0)
        entry = Entry(window)
        entry.grid(row=idx, column=1)
        entries[field] = entry

    style = {"bg": "#009688", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(window, text="Add", command=lambda: execute_add_customer(entries, window), **style).pack()

def execute_add_customer(entries, window):
    try:
        data = {field: entry.get() for field, entry in entries.items()}
        if bank.add_customer(data):
            messagebox.showinfo("Success", "New customer added successfully.")
        else:
            messagebox.showerror("Failed", "Failed to add new customer.")
        window.destroy()
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")
        window.destroy()

def edit_customer(parent):
    window = Toplevel(parent)
    window.title("Edit Customer")
    window.geometry("600x200")
    window.configure(bg="#FF5722")

    Label(window, text="Enter Last Name of Customer:").grid(row=0, column=0)
    lname = Entry(window)
    lname.grid(row=0, column=1)

    style = {"bg": "#FF5722", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(window, text="Edit", command=lambda: execute_edit_customer(lname.get(), window), **style).pack()

def execute_edit_customer(lname, window):
    customer = bank.search_customers_by_name(lname)
    if not customer:
        messagebox.showerror("Error", "Customer not found.")
        window.destroy()
        return

    edit_window = Toplevel(window)
    edit_window.title("Edit Customer Details")
    edit_window.geometry("600x400")
    edit_window.configure(bg="#E91E63")

    fields = "First Name", "Last Name", "Address", "Balance", "Account Type", "Interest Rate", "Overdraft Limit"
    current_values = customer.to_dict()  # Assumes you have a method to return customer details as a dictionary
    entries = {}
    for idx, field in enumerate(fields):
        Label(edit_window, text=field+":").grid(row=idx, column=0)
        entry = Entry(edit_window)
        entry.insert(0, current_values.get(field, ""))
        entry.grid(row=idx, column=1)
        entries[field] = entry

    style = {"bg": "#E91E63", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(edit_window, text="Update", command=lambda: execute_update_customer(customer, entries, edit_window), **style).pack()

def execute_update_customer(customer, entries, window):
    updated_values = {field: entry.get() for field, entry in entries.items()}
    if customer.update_details(updated_values):
        messagebox.showinfo("Success", "Customer details updated successfully.")
    else:
        messagebox.showerror("Failed", "Failed to update customer details.")
    window.destroy()

def transfer_money(parent):
    window = Toplevel(parent)
    window.title("Transfer Money")
    window.geometry("600x400")
    window.configure(bg="#FF9800")

    Label(window, text="Sender Last Name:").grid(row=0, column=0)
    sender_lname = Entry(window)
    sender_lname.grid(row=0, column=1)

    Label(window, text="Amount:").grid(row=1, column=0)
    amount = Entry(window)
    amount.grid(row=1, column=1)

    Label(window, text="Receiver Last Name:").grid(row=2, column=0)
    receiver_lname = Entry(window)
    receiver_lname.grid(row=2, column=1)

    Label(window, text="Receiver Account Number:").grid(row=3, column=0)
    receiver_account_no = Entry(window)
    receiver_account_no.grid(row=3, column=1)

    style = {"bg": "#FF9800", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(window, text="Proceed to Transfer", command=lambda: execute_transfer(
        sender_lname.get(), amount.get(), receiver_lname.get(), receiver_account_no.get(), window), **style).grid(row=4, column=0, columnspan=2, sticky="ew")

def execute_transfer(sender_lname, amount_str, receiver_lname, receiver_account_no_str, window):
    try:
        # Convert amount to float and receiver_account_no to int
        amount = float(amount_str)
        if amount <= 0:
            raise ValueError("The amount must be positive.")  # Ensuring positive amount
        receiver_account_no = int(receiver_account_no_str)

        # Placeholder for bank system transfer call
        success = bank.handle_money_transfer(sender_lname, amount, receiver_lname, receiver_account_no)
        if success:
            messagebox.showinfo("Success", "Money transferred successfully")
        else:
            messagebox.showerror("Error", "Transfer failed. Please check the details and try again.")
    except ValueError as e:
        # Handle errors in conversion (e.g., if input is not a valid number)
        messagebox.showerror("Error", f"Invalid input: {str(e)}")
    except Exception as e:
        # Handle any other unforeseen errors
        messagebox.showerror("Error", f"An error occurred: {str(e)}")
    finally:
        window.destroy()

def manage_customers(parent):
    window = Toplevel(parent)
    window.title("Manage Customers")
    window.geometry("600x400")
    window.configure(bg="#CDDC39")

    style = {"bg": "#CDDC39", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(window, text="Add Customer", command=lambda: add_customer(window), **style).pack(fill=tk.X, pady=5)
    Button(window, text="Edit Customer", command=lambda: edit_customer(window), **style).pack(fill=tk.X, pady=5)

def update_admin_info(parent, admin):
    window = Toplevel(parent)
    window.title("Update My Information")
    window.geometry("600x400")
    window.configure(bg="#FFEB3B")

    Label(window, text="New First Name:").grid(row=0, column=0)
    new_fname_entry = Entry(window)
    new_fname_entry.insert(0, admin.get_first_name())
    new_fname_entry.grid(row=0, column=1)

    Label(window, text="New Last Name:").grid(row=1, column=0)
    new_lname_entry = Entry(window)
    new_lname_entry.insert(0, admin.get_last_name())
    new_lname_entry.grid(row=1, column=1)

    Label(window, text="New Address (comma-separated):").grid(row=2, column=0)
    new_address_entry = Entry(window)
    # Ensure address is treated as a list, not a string that looks like a list
    address_components = admin.get_address()
    if isinstance(address_components, list):
        address_string = ', '.join(address_components)
    else:
        address_string = address_components  # or handle error/formatting issue
    new_address_entry.insert(0, address_string)
    new_address_entry.grid(row=2, column=1)

    style = {"bg": "#FFEB3B", "fg": "white", "font": ("Arial", 12, "bold"), "bd": 0, "highlightthickness": 0}
    Button(window, text="Update", command=lambda: execute_update_info(
        new_fname_entry.get(),
        new_lname_entry.get(),
        new_address_entry.get().split(', '),
        admin,
        window), **style).grid(row=3, column=0, columnspan=2, sticky="ew")

def execute_update_info(new_fname, new_lname, new_address, admin, window):
    # Trim spaces to avoid saving blank spaces as valid input
    new_fname = new_fname.strip()
    new_lname = new_lname.strip()

    # Validate first and last names are not empty
    if not new_fname or not new_lname:
        messagebox.showerror("Invalid Input", "First and last names cannot be empty.")
        return  # Return to avoid closing the window, allowing the user to correct the input

    # Validate address
    if not new_address or len(new_address) < 3:
        messagebox.showerror("Invalid Input", "Address must have (e.g., Street, City, Country).")
        return  # Return to avoid closing the window, allowing the user to correct the input

    # If all validations pass, update the admin information
    admin.update_name(new_fname, new_lname)
    admin.update_address(new_address)

    # Information updated successfully, now close the window
    messagebox.showinfo("Success", "Details updated successfully")
    window.destroy()

# destroys the root window and then quits the main loop
def quit_app(root):
    root.destroy()

def banksystem():
    root = tk.Tk()
    root.title("Banking System")
    root.geometry("800x600")
    root.configure(bg="#9E9E9E")
    Button(root, text="Admin Login", command=login, bg="#4CAF50", fg="white", font=("Arial", 12, "bold"), bd=0, highlightthickness=0).pack(fill=tk.X, pady=5)
    Button(root, text="Quit", command=lambda: quit_app(root), bg="#F44336", fg="white", font=("Arial", 12, "bold"), bd=0, highlightthickness=0).pack(fill=tk.X, pady=5)
    root.mainloop()

if __name__ == "__main__":
    banksystem()
