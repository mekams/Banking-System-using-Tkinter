#person class imported from person file.(inheritance)
from person import Person;

class Admin(Person):
    
    def __init__(self, fname, lname, address, user_name, password, full_rights):
        super().__init__(fname, lname, address)
        self.user_name = user_name
        self.password = password
        self.full_admin_rights = full_rights
    
    def get_username(self):
        return self.user_name

    def get_password(self):
        return self.password

    def set_full_admin_right(self, admin_right):
        self.full_admin_rights = admin_right

    def has_full_admin_right(self):
        return self.full_admin_rights
    
    def update_name(self, new_fname, new_lname):
        """Update the admin's first and last name."""
        self.fname = new_fname
        self.lname = new_lname
        print(f"Name updated to {self.fname} {self.lname}.")

    def update_address(self, new_address):
        """Update the admin's address."""
        self.address = new_address
        print(f"Address updated to {', '.join(self.address)}.")

    def serialize(self):
        address_str = '|'.join(self.address)
        return f"{self.fname},{self.lname},{address_str},{self.user_name},{self.password},{self.full_admin_rights}"

    @classmethod
    def deserialize(cls, data):
        fname, lname, address, user_name, password, full_rights = data.split(',')
        address = address.split('|')
        return cls(fname, lname, address, user_name, password, full_rights == 'True')