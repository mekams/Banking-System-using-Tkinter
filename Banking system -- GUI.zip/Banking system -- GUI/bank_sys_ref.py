from customer_account import CustomerAccount
from admin import Admin

accounts_list = []
admins_list = []

class BankSystem(object):
    def __init__(self):
        self.accounts_list = []
        self.admins_list = []
        self.load_bank_data()
    
    def load_bank_data(self):
        # Text File is loaded having the customer and admin details. 
        # Exception handling if no previous details found.
        try:
            with open('bank_data.txt', 'r') as file:
                for line in file:
                    if line.strip():
                        entry_type, data = line.strip().split(':', 1)
                        if entry_type == "Customer":
                            account = CustomerAccount.deserialize(data)
                            self.accounts_list.append(account)
                        elif entry_type == "Admin":
                            admin = Admin.deserialize(data)
                            self.admins_list.append(admin)
            print("Bank data loaded successfully.")
        except FileNotFoundError:
            print("No existing bank data found, starting fresh.")
            self.create_initial_accounts()
        
            # When all the operations are performed the updated data can be saved to the text file.
    def save_bank_data(self):
        with open('bank_data.txt', 'w') as file:
            for account in self.accounts_list:
                file.write(f"Customer:{account.serialize()}\n")
            for admin in self.admins_list:
                file.write(f"Admin:{admin.serialize()}\n")
        print("Bank data saved successfully.")   
        
        
    def create_initial_accounts(self):
        
        # List of initial customers to be added
        initial_customers = [
            {"fname": "Adam", "lname": "Smith", "address": ["14", "Wilcot Street", "Bath", "B5 5RT"], "account_no": 1001, "balance": 5000.00, "account_type": "current", "interest_rate": 0.5, "overdraft_limit": 1000.00},
            {"fname": "David", "lname": "White", "address": ["60", "Holborn Viaduct", "London", "EC1A 2FD"], "account_no": 1002, "balance": 3200.00, "account_type": "savings", "interest_rate": 1.2, "overdraft_limit": 500.00},
            {"fname": "Alice", "lname": "Churchil", "address": ["5", "Cardigan Street", "Birmingham", "B4 7BD"], "account_no": 1003, "balance": 18000.00, "account_type": "savings", "interest_rate": 1.5, "overdraft_limit": 1500.00},
            {"fname": "Ali", "lname": "Abdallah", "address": ["44", "Churchill Way West", "Basingstoke", "RG21 6YR"], "account_no": 1004, "balance": 40.00, "account_type": "current", "interest_rate": 0.2, "overdraft_limit": 200.00}
        ]
    
        # Creating CustomerAccount objects and appending them to the accounts list
        for customer in initial_customers:
            new_account = CustomerAccount(
                fname=customer["fname"],
                lname=customer["lname"],
                address=customer["address"],
                account_no=customer["account_no"],
                balance=customer["balance"],
                account_type=customer["account_type"],
                interest_rate=customer["interest_rate"],
                overdraft_limit=customer["overdraft_limit"]
            )
            self.accounts_list.append(new_account)
        print("Initial customer accounts created successfully.")
        
        """Manually create initial admin accounts if no data file exists."""
        initial_admins = [
            {"fname": "Julian", "lname": "Padget", "address": ["12", "London Road", "Birmingham", "B95 7TT"], "user_name": "id1188", "password": "1441", "full_rights": True},
            {"fname": "Cathy", "lname": "Newman", "address": ["47", "Mars Street", "Newcastle", "NE12 6TZ"], "user_name": "id3313", "password": "2442", "full_rights": False},
        ]
    
        for admin in initial_admins:
            new_admin = Admin(
                fname=admin["fname"],
                lname=admin["lname"],
                address=admin["address"],
                user_name=admin["user_name"],
                password=admin["password"],
                full_rights=admin["full_rights"]
            )
            self.admins_list.append(new_admin)
        print("Initial admin accounts created successfully.")        


    def search_admins_by_name(self, admin_username):
        found_admin = None
        for a in self.admins_list:
            username = a.get_username()
            if username == admin_username:
                found_admin = a
                break
        if found_admin == None:
            print("\n The Admin %s does not exist! Try again...\n" %admin_username) 
        return found_admin
        pass  
        
    def search_customers_by_name(self, customer_lname):
        found_customer = None
        for a in self.accounts_list:
            last_name = a.get_last_name()
            if last_name == customer_lname:
                found_customer = a
                break
        if found_customer == None:
            print("\n The Customer %s does not exist! Try again...\n" %customer_lname) 
        return found_customer
        pass

      #Main Menu
    def main_menu(self):
      while True:  # Loop keep asking for the input until a valid option is selected.
          try:
              print("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
              print("Welcome to the Python Bank System")
              print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
              print("1) Admin login")
              print("2) Quit")
              print(" ")
  
              option = int(input("Choose your option: "))  # Convert input into an integer for valid option selection.
  
              if option in [1, 2]:  # Checks the input whether it is one of the valid option.
                  return option
              else:
                  print("Invalid option. Please enter 1 or 2.")  # In case of input is out of expected range, user will be informed.
  
          except ValueError:  # Catch the error if conversion to integer failed.
              print("Invalid input. Please enter a number.")  # User is informed if input is not a number.


    def run_main_options(self):
        while True:  # Implement a control method for the loop that is more intuitive and user-friendly.
            try:
                choice = self.main_menu()
                if choice == 1:
                    username = input("\n Please input admin username (case-sensitive): ")
                    password = input("\n Please input admin password (case-sensitive): ")
                    
                    # Ensures that inputs are validated before proceeding with the login attempt.
                    if not username or not password:
                        print("Username and password cannot be empty. Please try again.")
                        continue
                    
                    msg, admin_obj = self.admin_login(username, password)
                    print(msg)
                    if admin_obj is not None:
                        self.run_admin_options(admin_obj)
                    else:
                        print("Login failed. Please check your credentials and try again.")
                    
                elif choice == 2:
                    print("\n Thank You \n Revisit Us - Goodbye!")
                    break  # Break the loop when user chooses to quit so finally program stops.
                else:
                    print("Invalid choice. Please select 1 or 2.")
            
            except Exception as e:  # Catch any unexpected exceptions that may occur
                print(f"An error occurred: {e}. Please try again.")
        
        
            
    def handle_money_transfer(self, sender_lname, amount, receiver_lname, receiver_account_no):
        print(f"Attempting to transfer {amount} from {sender_lname} to {receiver_lname} with account number {receiver_account_no}")
        sender = self.search_customers_by_name(sender_lname)
        receiver = next((acc for acc in self.accounts_list if acc.get_account_no() == int(receiver_account_no) and acc.get_last_name() == receiver_lname), None)
    
        if sender:
            print(f"Sender found: {sender.get_first_name()} {sender.get_last_name()} with balance {sender.get_balance()}")
        else:
            print("Sender not found.")
        
        if receiver:
            print(f"Receiver found: {receiver.get_first_name()} {receiver.get_last_name()} with account number {receiver.get_account_no()}")
        else:
            print("Receiver not found.")
    
        if sender and receiver:
            if sender.get_balance() >= amount:
                print("Balance sufficient for transfer.")
                sender.withdraw(amount)
                receiver.deposit(amount)
                print(f"Transferred {amount} from {sender.get_first_name()} {sender.get_last_name()} to {receiver.get_first_name()} {receiver.get_last_name()}.")
                return True
            else:
                print("Insufficient balance for the transaction.")
        else:
            print("Transaction failed. Either sender or receiver does not exist.")
        return False
                
    def run_customer_account_options(self):
        customer_name = input("\n Please input customer surname: ")
        customer_account = self.search_customers_by_name(customer_name)
        if customer_account:
            customer_account.run_account_options()
        else:
            print("\n No customer found with that surname.")        


    def delete_customer(self, lname_to_delete):
        print(lname_to_delete);
        customer_to_delete = self.search_customers_by_name(lname_to_delete)
        if customer_to_delete:
            self.accounts_list.remove(customer_to_delete)
            print(f"\n Customer {lname_to_delete} deleted successfully.")
        else:
            print("\n Customer not found.")

    def print_all_accounts_details(self):
        details = "All customers' details:\n"
        for i, customer in enumerate(self.accounts_list, start=1):
            detail = f"{i}. {customer.get_details()}\n"  # Assuming each CustomerAccount has a method `get_details` that returns a formatted string of details
            details += detail + "------------------------\n"
            print(f'\n {i}. ', end=' ')
            customer.print_details()
        return details


    def edit_customer(self):
        try:
            lname_to_edit = input("\nEnter last name of customer to edit: ")
            if not lname_to_edit.strip():
                print("Last name cannot be empty. Please try again.")
                return
    
            customer_to_edit = self.search_customers_by_name(lname_to_edit.strip())
            if customer_to_edit:
                new_fname = input("Enter new first name (leave blank to keep current): ").strip()
                new_lname = input("Enter new last name (leave blank to keep current): ").strip()
                new_address_input = input("Enter new address (comma-separated, leave blank to keep current): ").strip()
    
                if new_fname:
                    customer_to_edit.update_first_name(new_fname)
                if new_lname:
                    customer_to_edit.update_last_name(new_lname)
                if new_address_input:
                    new_address = new_address_input.split(',')
                    if len(new_address) != 4:  # Assuming address should consist of exactly four parts
                        print("Please enter a complete address in the format: House Number, Street, City, Postcode.")
                    else:
                        customer_to_edit.update_address(new_address)
    
                print("\n Customer details updated successfully.")
            else:
                print("\n Customer not found.")
        except Exception as e:
            print(f"An unexpected error occurred: {e}. Please try again.")
    
                
            
    def transferMoney(self):
        self.handle_money_transfer()
        pass

                
    def admin_login(self, username, password):
        found_admin = self.search_admins_by_name(username)  
        msg = "\nLogin failed"
        if found_admin is not None:
            if found_admin.get_password() == password:
                msg = "\nLogin successful"
                return msg, found_admin  # Return the admin object on successful login
            else:
                msg += ": Incorrect password"
        else:
            msg += ": Username not found"
        return msg, None  # Return None if the login is not successful
 

    def admin_menu(self, admin_obj):
        while True:  # Ensure the menu keeps displaying until valid input is entered
            try:
                print("\nWelcome Admin %s %s : Available options are:" % (admin_obj.get_first_name(), admin_obj.get_last_name()))
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                print("1) Transfer money")
                print("2) Customer account operations & profile settings")
                print("3) Delete customer")
                print("4) Save data")
                print("5) Print all customers detail")
                print("6) Update My Information")
                print("7) Generate Management Report")
                print("8) Sign out")
                print(" ")
    
                option = int(input("Choose your option: "))  # Attempt to convert input into an integer
    
                if 1 <= option <= 9:  # Validate if the option is within the valid range
                    return option
                else:
                    print("Invalid option. Please select from the options 1-9.")  # Prompt if outside valid range
    
            except ValueError:  # Catch the error if conversion to integer fails
                print("Invalid input. Please enter a number.")  # Inform the user if input is not a number
                
    def update_admin_info(self, admin_obj):
        print("Update My Information:")
        new_fname = input("Enter new first name (leave blank to keep current): ").strip()
        new_lname = input("Enter new last name (leave blank to keep current): ").strip()
        new_address = input("Enter new address (comma-separated, leave blank to keep current): ").strip().split(',')
    
        if new_fname and new_lname:
            admin_obj.update_name(new_fname, new_lname)
        if new_address:
            admin_obj.update_address(new_address)
        print("Information updated successfully.")
        
    def generate_management_report(self):
        total_customers = len(self.accounts_list)
        total_balance = sum(account.balance for account in self.accounts_list)
        total_interest_payable = sum(account.balance * (account.interest_rate / 100) for account in self.accounts_list if account.balance > 0)
        total_overdrafts_taken = sum(account.overdraft_limit for account in self.accounts_list if account.balance < 0)
    
        print("\nManagement Report:")
        print(f"Total Number of Customers: {total_customers}")
        print(f"Total Balance Across All Accounts: ${total_balance:,.2f}")
        print(f"Total Interest Payable for One Year: ${total_interest_payable:,.2f}")
        print(f"Total Overdrafts Currently Taken: ${total_overdrafts_taken:,.2f}")  
        report = "\nManagement Report:\n"
        report += f"Total Number of Customers: {total_customers}\n"
        report += f"Total Balance Across All Accounts: ${total_balance:,.2f}\n"
        report += f"Total Interest Payable for One Year: ${total_interest_payable:,.2f}\n"
        report += f"Total Overdrafts Currently Taken: ${total_overdrafts_taken:,.2f}"
        
        return report


    def run_admin_options(self, admin_obj):                                
        loop = 1
        while loop == 1:
            choice = self.admin_menu(admin_obj)
            if choice == 1:
                self.transferMoney()               
            elif choice == 2:
                self.run_customer_account_options()
                pass            
            elif choice == 3:
                self.delete_customer()
                pass            
            elif choice == 4:
                self.save_bank_data()
                pass  
            elif choice == 5:
                self.print_all_accounts_details()
                pass
            elif choice == 6:
                self.update_admin_info(admin_obj)
            elif choice == 7:
                self.generate_management_report()       
            elif choice == 8:
                loop = 0
        print ("\n Exit account operations")


app = BankSystem()
