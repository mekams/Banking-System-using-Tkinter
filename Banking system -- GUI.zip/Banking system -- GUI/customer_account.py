#Person class imported from person file.(inheritance)

from person import Person;

class CustomerAccount(Person):
    def __init__(self, fname, lname, address, account_no, balance, account_type, interest_rate=0.0, overdraft_limit=0.0):
        super().__init__(fname, lname, address)
        self.account_no = account_no
        self.balance = float(balance)
        self.account_type = account_type  # New attribute to distinguish account types
        self.interest_rate = interest_rate  # Interest rate applicable to the account
        self.overdraft_limit = overdraft_limit  # Overdraft limit for the account
    
    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"{amount} deposited. New balance is {self.balance}.")
        else:
            print("Deposit amount must be positive.")

    def withdraw(self, amount):
        if amount <= 0:
            print("Withdrawal amount must be positive.")
            return False
        if self.balance + self.overdraft_limit >= amount:
            self.balance -= amount
            print(f"{amount} withdrawn. New balance is {self.balance}.")
            return True
        else:
            print("Insufficient funds.")
            return False

    def print_balance(self):
        print("\n The account balance is %.2f" %self.balance)
        
    def get_balance(self):
        return self.balance

    def get_account_no(self):
        return self.account_no
    
    def account_menu(self):
        while True:  # Continuously prompt for input until valid
            try:
                print("\nYour Transaction Options Are:")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                print("1) Deposit money")
                print("2) Withdraw money")
                print("3) Check balance")
                print("4) Update customer name")
                print("5) Update customer address")
                print("6) Show customer details")
                print("7) Back")
                print(" ")
    
                option = int(input("Choose your option: "))  # Convert input to integer
    
                if 1 <= option <= 7:  # Check if option is within the allowed range
                    return option
                else:
                    print("Invalid option. Please select a number between 1 and 7.")  # Error message for out of range
    
            except ValueError:  # If conversion to integer fails
                print("Invalid input. Please enter a number.")  # Error message for non-integer inputs

    
    def print_details(self):
        print(f"First name: {self.fname}")
        print(f"Last name: {self.lname}")
        print(f"Account No: {self.account_no}")
        print(f"Address: {', '.join(self.address)}")
        print(f"Account No: {self.account_no}, Type: {self.account_type}, Balance: {self.balance}, "
       f"Interest Rate: {self.interest_rate}%, Overdraft Limit: {self.overdraft_limit}")
        print(" ")
        
    def get_details(self):
        return f"Account No: {self.account_no}, Name: {self.fname} {self.lname}, Balance: ${self.balance:.2f}, Interest Rate: {self.interest_rate}%, Overdraft Limit: {self.overdraft_limit}"        
        
    def serialize(self):
        # Converts object to a string for file saving
        address_str = '|'.join(self.address)
        return f"{self.fname},{self.lname},{address_str},{self.account_no},{self.balance},{self.account_type},{self.interest_rate},{self.overdraft_limit}"

    @classmethod
    def deserialize(cls, data):
        # Creates an object from a string
        fname, lname, address, account_no, balance, account_type, interest_rate, overdraft_limit = data.split(',')
        address = address.split('|')
        return cls(fname, lname, address, int(account_no), float(balance), account_type, float(interest_rate), float(overdraft_limit))    
    
    def run_account_options(self):
        while True:
            choice = self.account_menu()
            try:
                if choice == 1:
                    amount = float(input("\n Please enter amount to be deposited: "))
                    if amount < 0:
                        print("Amount cannot be negative. Please enter a valid amount.")
                        continue
                    self.deposit(amount)
    
                elif choice == 2:
                    amount = float(input("\n Please enter amount to withdraw: "))
                    if amount < 0:
                        print("Amount cannot be negative. Please enter a valid amount.")
                        continue
                    self.withdraw(amount)
    
                elif choice == 3:
                    self.print_balance()
    
                elif choice == 4:
                    fname = input("\n Enter new customer first name: ").strip()
                    lname = input("\n Enter new customer last name: ").strip()
                    if not fname or not lname:
                        print("First name and last name cannot be empty.")
                        continue
                    self.update_first_name(fname)
                    self.update_last_name(lname)
    
                elif choice == 5:
                    new_address_input = input("\n Enter new customer address (comma-separated): ")
                    new_address = new_address_input.split(',')
                    if len(new_address) != 4:  # Assuming the address must have exactly four parts
                        print("Please enter a complete address in the format: House Number, Street, City, Postcode.")
                        continue
                    self.update_address(new_address)
    
                elif choice == 6:
                    self.print_details()
    
                elif choice == 7:
                    print("\n Exit account operations")
                    break
    
            except ValueError:
                print("Please enter a valid number for the amount.")
    
            